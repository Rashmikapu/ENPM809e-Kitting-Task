from launch import LaunchDescription
from launch_ros.actions import Node
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.actions import IncludeLaunchDescription
from launch_ros.substitutions import FindPackageShare
import os
from ariac_moveit_config.parameters import generate_parameters
from ament_index_python.packages import get_package_share_directory


parameter_file = os.path.join(
    get_package_share_directory('rwa4_17'),
    'config',
    'order.yaml')


def generate_launch_description():
    launch_description = LaunchDescription()
    # Robot Commander Node
    # robot_commander = Node(
    #     package="robot_commander",
    #     executable="floor_robot_commander",
    #     output="screen",
    #     parameters=generate_parameters()
    # )

    my_node = Node(
        package="rwa4_17",
        executable="rwa4_17",
        parameters=[parameter_file]
    )

    # initiate_node = Node(
    #     package='robot_commander',
    #     executable="floor_robot_main",
    #     output="screen",
    #     parameters=generate_parameters()
    # )

    

    # MoveIt node
    # moveit = IncludeLaunchDescription(
    #     PythonLaunchDescriptionSource(
    #         [FindPackageShare("ariac_moveit_config"), "/launch", "/ariac_robots_moveit.launch.py"]
    #     )
    # )
    # launch_description.add_action(robot_commander)
    launch_description.add_action(my_node)
    #launch_description.add_action(initiate_node)
    # launch_description.add_action(moveit)
    return launch_description
    #return LaunchDescription([robot_commander, my_node, initiate_node, moveit])