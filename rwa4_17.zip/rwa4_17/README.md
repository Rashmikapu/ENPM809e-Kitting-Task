# enpm809e_final_spring2023

- Packages for the final project for ENPM809E Spring 2023.
- See PDF for more details.

Terminal 1

ros2 launch ariac_gazebo ariac.launch.py trial_name:=final

Terminal 2

 ros2 launch robot_commander robot_commander.launch.py  
 
 Terminal 3 
 ros2 launch rwa4_17 rwa4_17.launch.py
