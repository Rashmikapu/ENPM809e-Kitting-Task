# ========================================
# ENPM809E Spring 2023: Application for python programming
# rwa4
# ========================================
# Author: Rashmi Kapu (rashmik@umd.edu)
# UID: 119461754
# Directory ID: rashmik

# Author: Rishab Namdev (rnamdev@umd.edu)
# UID: 119480977
# Directory ID: rishabnamdev
# ========================================
# Press CTRL+C for exit




from ariac_msgs.srv import MoveAGV, ChangeGripper, VacuumGripperControl
from std_srvs.srv import Trigger
import rclpy
import PyKDL
from rclpy.node import Node
from geometry_msgs.msg import Pose
from tf_package.tf_node import *
from ariac_msgs.msg import Order, PartPose, Part, KitTrayPose 
from ariac_msgs.msg import AdvancedLogicalCameraImage, KittingTask, Part, KittingPart
#from example_interfaces.msg import *
from rclpy.executors import MultiThreadedExecutor
from rclpy.callback_groups import MutuallyExclusiveCallbackGroup
from rclpy.qos import QoSDurabilityPolicy, QoSHistoryPolicy, QoSReliabilityPolicy
from rclpy.qos import QoSProfile
from competitor_interfaces.msg import Robots as RobotsMsg
from competitor_interfaces.srv import EnterToolChanger, ExitToolChanger, PickupTray, MoveTrayToAGV, MovePartToAGV, PlacePartInTray, RetractFromAGV, PickupPart, PlaceTrayOnAGV
from ariac_msgs.msg import CompetitionState
from ament_index_python.packages import get_package_share_directory


class AdvancedCamera:
    '''
    Class holds messages from left camera, right camera, left bins, right bins

    Class variables : part_poses , tray_poses, sensor_pose
    '''
    def __init__(self, msg):
        self.part_poses = msg.part_poses
        self.tray_poses = msg.tray_poses
        self.sensor_pose = msg.sensor_pose
    

class Orders:
    '''
    Class holds messages of Orders announced

    Class variables : id, priority_type, agv, kitting_task, parts
    '''
    def __init__(self, msg):
        self.id = msg.id
        self.priority = msg.priority
        self.type = msg.type
        self.agv_number = msg.kitting_task.agv_number
        self.tray_id = msg.kitting_task.tray_id
        self.destination = msg.kitting_task.destination
        self.parts = []
        for part in msg.kitting_task.parts: 
            part_dict = { # dict for each part
                'color': part.part.color, 
                'type': part.part.type,
                'quadrant': part.quadrant
            }
            self.parts.append(part_dict)

class ClientNode(Node):
    '''
    Simple class to create a ROS2 node

    Args:
        Node (class): ROS2 node class
    '''

    def __init__(self, node_name):
        super().__init__(node_name)
        
        topic_group = MutuallyExclusiveCallbackGroup()
        service_group = MutuallyExclusiveCallbackGroup()
        timer_group = MutuallyExclusiveCallbackGroup()

        self.orders_dict = {}  # Key: All Order IDs, Value: All Order objects
        self.current_order = None        
        self.order_Dictionary = {}
        
        qos_profile = QoSProfile(depth=10)
        qos_profile.reliability = QoSReliabilityPolicy.BEST_EFFORT
        qos_profile.durability = QoSDurabilityPolicy.VOLATILE
                
        self.declare_parameters(namespace='', parameters=[("order_id", "")])

        # self.order_id = self.read_yaml(parameter_file)['rwa4']['ros__parameters']['order_id']
        self._kit_completed = False
        self._competition_state = None
        self._competition_started = False
        self.get_logger().info(f'{node_name} node running')
        #-----------------------------
        self._start_competition_client = self.create_client(Trigger, '/ariac/start_competition', callback_group=service_group)
        self._enter_tool_changer_client = self.create_client(EnterToolChanger, '/competitor/floor_robot/enter_tool_changer', callback_group=service_group)
        self._exit_tool_changer_client = self.create_client(ExitToolChanger, '/competitor/floor_robot/exit_tool_changer', callback_group=service_group)
        self._go_home = self.create_client(Trigger, '/competitor/floor_robot/go_home', callback_group=service_group)
        self._pickup_tray = self.create_client(PickupTray, '/competitor/floor_robot/pickup_tray', callback_group=service_group)
        self._move_tray_to_agv = self.create_client(MoveTrayToAGV, '/competitor/floor_robot/move_tray_to_agv', callback_group=service_group)
        self._place_tray_on_agv_client = self.create_client(PlaceTrayOnAGV, '/competitor/floor_robot/place_tray_on_agv', callback_group=service_group)
        self._retract_from_agv = self.create_client(RetractFromAGV, '/competitor/floor_robot/retract_from_agv',callback_group=service_group)
        self._pickup_part = self.create_client(PickupPart, '/competitor/floor_robot/pickup_part', callback_group=service_group)
        self._move_part_to_agv = self.create_client(MovePartToAGV,'/competitor/floor_robot/move_part_to_agv', callback_group=service_group)
        self._place_part_in_tray = self.create_client(PlacePartInTray,'/competitor/floor_robot/place_part_in_tray', callback_group=service_group)
        
        self._agv1_lock_tray = self.create_client(Trigger, '/ariac/agv1_lock_tray', callback_group=service_group)
        self._agv2_lock_tray = self.create_client(Trigger, '/ariac/agv2_lock_tray', callback_group=service_group)
        self._agv3_lock_tray = self.create_client(Trigger, '/ariac/agv3_lock_tray', callback_group=service_group)
        self._agv4_lock_tray = self.create_client(Trigger, '/ariac/agv4_lock_tray', callback_group=service_group)
        
        self._move_agv1 = self.create_client(MoveAGV, '/ariac/move_agv1', callback_group=service_group)
        self._move_agv2 = self.create_client(MoveAGV, '/ariac/move_agv2', callback_group=service_group)
        self._move_agv3 = self.create_client(MoveAGV, '/ariac/move_agv3', callback_group=service_group)
        self._move_agv4 = self.create_client(MoveAGV, '/ariac/move_agv4', callback_group=service_group)

        self._robot_change_gripper = self.create_client(ChangeGripper, '/ariac/floor_robot_change_gripper', callback_group=service_group)
        self._enable_gripper = self.create_client(VacuumGripperControl, '/ariac/floor_robot_enable_gripper', callback_group=service_group)
        # Service client for entering the gripper slot
        self._goto_tool_changer_client = self.create_client(
            EnterToolChanger, '/competitor/floor_robot/enter_tool_changer',
            callback_group=service_group)
        
        self.tf = None
        self._robot_action_timer = self.create_timer(1, self._robot_action_timer_callback,
                                                     callback_group=timer_group)
        
        #-------------------------------------
        self._subscriber_order = self.create_subscription(Order, '/ariac/orders',
                                                     self._subscriber_order_callback,
                                                     10)
                                                    #  callback_group=topic_group)
        
        self._subscriber_table1_camera = self.create_subscription(AdvancedLogicalCameraImage, '/ariac/sensors/table1_camera/image',
                                                     self._subscriber_table1_callback,
                                                     qos_profile)
        
        self._subscriber_table2_camera = self.create_subscription(AdvancedLogicalCameraImage,'/ariac/sensors/table2_camera/image',
                                                     self._subscriber_table2_callback,
                                                     qos_profile)
        

        self._subscriber_leftbin_camera = self.create_subscription(AdvancedLogicalCameraImage,'/ariac/sensors/left_bins_camera/image',
                                                     self._subscriber_leftbin_callback,
                                                     qos_profile)
        

        self._subscriber_rightbin_camera = self.create_subscription(AdvancedLogicalCameraImage,'/ariac/sensors/right_bins_camera/image',
                                                     self._subscriber_rightbin_callback,
                                                     qos_profile)
        
        self._subscriber_competition_state = self.create_subscription(CompetitionState, '/ariac/competition_state',
                                                    self._competition_state_cb, 
                                                    10,
                                                    callback_group=topic_group)
       

    #-----------------------------------------------------------------------------

    # def read_yaml(self, path):
    #     with open(path, "r") as stream:
    #         try:
    #             return yaml.safe_load(stream)
    #         except yaml.YAMLError:
    #             self.get_logger().error("Unable to read configuration file")
    #             return {}
            
    
    def _subscriber_order_callback(self, msg):
        """
            Callback function to manage the incoming messages from the topic /ariac/orders.

            Args:
                msg: contains announcement that gazebo makes for the order.

            Returns:
                None

            Behavior:
                Splits the information from the message and stores it in class variables

        """   
        self.get_logger().info("inside order callback")
        order = Orders(msg)
        self.orders_dict[order.id] = order


    def _subscriber_table1_callback(self, msg):
        """
    Incoming messages from the table 1 camera topic.

    Args:
        msg: Contains information about the camera readings i.e the camera coordinates of the tray.

    Returns:
        None

    Behavior:
        Extracts information from the message object and sets instance variables.
        Calculates the transformation between the tray and the sensor pose with respect to world coordinates.
        Prints the data (position, orientation etc)

    """
        self.get_logger().info("Table1 cb")
        self.table1 = AdvancedCamera(msg)
                
            
        
    def _subscriber_table2_callback(self, msg):
        """
    Incoming messages from the table 2 camera topic.

    Args:
        msg: Contains information about the camera readings i.e the camera coordinates of the tray.

    Returns:
        None

    Behavior:
        Extracts information from the message object and sets instance variables.
        Calculates the transformation between the tray and the sensor pose with respect to world coordinates.
        Prints the data (position, orientation etc)

    """
        self.get_logger().info("Table2 cb")
        self.table2 = AdvancedCamera(msg)


    def _subscriber_leftbin_callback(self, msg):
        """
    Incoming messages from the left bins camera topic.

    Args:
        msg: Contains information about the camera readings i.e the camera coordinates of the parts.

    Returns:
        None

    Behavior:
        Extracts information from the message object and sets instance variables.
        Calculates the transformation between the part and the sensor pose with respect to world coordinates.
        Prints the data (position, orientation )

    """
        self.get_logger().info("LB cb")
        self.leftbin = AdvancedCamera(msg)
        

    def _subscriber_rightbin_callback(self, msg):
        """
    Incoming messages from the right bins camera topic.

    Args:
        msg: Contains information about the camera readings i.e the camera coordinates of the parts.

    Returns:
        None

    Behavior:
        Extracts information from the message object and sets instance variables.
        Calculates the transformation between the part and the sensor pose with respect to world coordinates.
        Prints the data (position, orientation )

    """
        self.get_logger().info("RB cb")
        self.rightbin = AdvancedCamera(msg)

    #-------------------------------------------------------------------------------------------
    def multiply_pose(self, pose1, pose2):
        '''
        Use KDL to multiply two poses together.
        Args:
            pose1 (Pose): Pose of the first frame
            pose2 (Pose): Pose of the second frame
        Returns:
            Pose: Pose of the resulting frame
        '''

        orientation1 = pose1.orientation
        frame1 = PyKDL.Frame(
            PyKDL.Rotation.Quaternion(orientation1.x, orientation1.y, orientation1.z, orientation1.w),
            PyKDL.Vector(pose1.position.x, pose1.position.y, pose1.position.z))

        orientation2 = pose2.orientation
        frame2 = PyKDL.Frame(
            PyKDL.Rotation.Quaternion(orientation2.x, orientation2.y, orientation2.z, orientation2.w),
            PyKDL.Vector(pose2.position.x, pose2.position.y, pose2.position.z))

        frame3 = frame1 * frame2

        # return the resulting pose from frame3
        pose = Pose()
        pose.position.x = frame3.p.x()
        pose.position.y = frame3.p.y()
        pose.position.z = frame3.p.z()

        q = frame3.M.GetQuaternion()
        pose.orientation.x = q[0]
        pose.orientation.y = q[1]
        pose.orientation.z = q[2]
        pose.orientation.w = q[3]

        return pose
    

    #-----------------------------------------------------------------------------------------

    def _robot_action_timer_callback(self):
        '''
        Callback for the timer that triggers the robot actions
        '''

        if self._competition_state == CompetitionState.READY and not self._competition_started: 
            self.start_competition()

        # exit the callback if the kit is completed
        if self._kit_completed:
            return

        id = self.get_parameter("order_id").value
        id = int(id)
        
        self.move_robot_home("floor_robot")

        for key in self.orders_dict:
            if int(key) == id:
                self.get_logger().info("Order Key: %d" % int(key))
                self.current_order = self.orders_dict[key]
                break

        agv = "agv" + str(self.current_order.agv_number)

        tray_id = self.current_order.tray_id
        kts1_trays = self.table1
        kts2_trays = self.table2
        trays = [kts1_trays, kts2_trays]

        for tray in trays:
            for k in range(len(tray.tray_poses)):
                if tray_id == tray.tray_poses[k].id:
                    if tray == kts1_trays:
                        tray_table = "kts1"
                    else:
                        tray_table = "kts2"
                    tray_pose = self.multiply_pose(tray.sensor_pose, tray.tray_poses[k].pose)
                    break

        # change gripper type
        tray_gripper = 2
        self.goto_tool_changer("floor_robot", tray_table, "trays")
        self.robot_change_gripper(tray_gripper)
        self.exit_tool_changer("floor_robot" , tray_table , "trays")
        self.get_logger().info("Came out of the exit_tool_changer")
        
    #-----------------------------------------
        
        self.pickup_tray("floor_robot", tray_id , tray_pose , tray_table)
        
        self.move_tray_to_agv("floor_robot", tray_pose, agv)
        self.place_tray_on_agv("floor_robot", tray_id, agv)
        self.retract_from_agv("floor_robot", agv)

    #-----------------------------------------
        count = 0
        for part in self.current_order.parts: 
            part_color, part_type, quadrant = part['color'], part['type'], part['quadrant'] 

            bin_parts = [self.leftbin, self.rightbin]

            for p in bin_parts:
                for j in range(len(p.part_poses)):
                    if part_color == p.part_poses[j].part.color: 
                        if part_type == p.part_poses[j].part.type:
                            part_pose = self.multiply_pose(p.sensor_pose, p.part_poses[j].pose)
                            break

            if part_pose.position.y > 0:
                bin_side = "right_bins"
                gripper_station = "kts2"
            else:
                bin_side = "left_bins"
                gripper_station = "kts1"

            if count == 0:
                part_gripper = 1
                self.goto_tool_changer("floor_robot", gripper_station, "parts")
                self.robot_change_gripper(part_gripper) 
                self.exit_tool_changer("floor_robot", gripper_station, "parts")
                count += 1
            
            self.pickup_part("floor_robot", part_pose, part_type, part_color, bin_side)
            self.move_part_to_agv("floor_robot", part_pose, agv, quadrant)
            self.place_part_in_tray("floor_robot", agv, quadrant)
            self.retract_from_agv("floor_robot", agv)

        self.move_robot_home("floor_robot")
        self.agv_lock_tray(agv)
        self.move_agv(agv)

        # to ignore function calls in this callback
        self._kit_completed = True


    #----------------------------------------------------------------------------------------------------
    def goto_tool_changer(self, robot, station, gripper_type):
        '''
        Move the end effector inside the gripper slot.

        Args:
            station (str): Gripper station name
            gripper_type (str): Gripper type

        Raises:
            KeyboardInterrupt: Exception raised when the user presses Ctrl+C
        '''

        self.get_logger().info('Move inside gripper slot service called')

        request = EnterToolChanger.Request()

        if robot == "floor_robot":
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError('Invalid robot name')

        request.station = station
        request.gripper_type = gripper_type

        future = self._goto_tool_changer_client.call_async(request)

        try:
            rclpy.spin_until_future_complete(self, future)
        except KeyboardInterrupt as kb_error:
            raise KeyboardInterrupt from kb_error

        if future.result() is not None:
            response = future.result()
            if response:
                self.get_logger().info('Robot is at the tool changer')
        else:
            self.get_logger().error(f'Service call failed {future.exception()}')
            self.get_logger().error('Unable to move the robot to the tool changer')

    #-------------------------------------------------------------------------------------------------------
    def _competition_state_cb(self, msg: CompetitionState):
        '''
        /ariac/competition_state topic callback function

        Args:
            msg (CompetitionState): CompetitionState message
        '''
        self._competition_state = msg.competition_state
    #-------------------------------------------------------------------------------------------------------------------------------#
    def start_competition(self):
        '''
        Start the competition
        '''
        self.get_logger().info('Waiting for competition state READY')

        request = Trigger.Request()
        future = self._start_competition_client.call_async(request)

        # Wait until the service call is completed
        rclpy.spin_until_future_complete(self, future)

        if future.result().success  :
            self.get_logger().info('Started competition.')
            self._competition_started = True
        else:
            self.get_logger().warn('Unable to start competition')


    #-------------------------------------------------------------------------------------------------------------------------------#
    def enter_tool_changer(self, robot, station, gripper_type):
        '''
        Move the end effector inside the gripper slot.

        Args:
            station (str): Gripper station name
            gripper_type (str): Gripper type

        Raises:
            KeyboardInterrupt: Exception raised when the user presses Ctrl+C
        '''

        self.get_logger().info('Move inside gripper slot service called')

        request = EnterToolChanger.Request()

        if robot == "floor_robot":
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError('Invalid robot name')

        request.station = station
        request.gripper_type = gripper_type

        future = self._enter_tool_changer_client.call_async(request)

        try:
            rclpy.spin_until_future_complete(self, future)
        except KeyboardInterrupt as kb_error:
            raise KeyboardInterrupt from kb_error

        if future.result() is not None:
            response = future.result()
            if response:
                self.get_logger().info('Robot is at the tool changer')
        else:
            self.get_logger().error(f'Service call failed {future.exception()}')
            self.get_logger().error('Unable to move the robot to the tool changer')



    #-------------------------------------------------------------------------------------------------------------------------------#
    def exit_tool_changer(self, robot, station, gripper_type):
        '''
        Move the end effector outside the gripper slot.

        Args:
            robot (str): Robot name
            station (str): Gripper station name
            gripper_type (str): Gripper type

        Raises:
            KeyboardInterrupt: Exception raised when the user presses Ctrl+C
        '''

        self.get_logger().info('Move outside gripper slot service called')

        request = ExitToolChanger.Request()

        if robot == "floor_robot":
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError('Invalid robot name')

        request.station = station
        request.gripper_type = gripper_type

        future = self._exit_tool_changer_client.call_async(request)

        try:
            rclpy.spin_until_future_complete(self, future)
        except KeyboardInterrupt as kb_error:
            raise KeyboardInterrupt from kb_error

        if future.result() is not None:
            response = future.result()
            if response:
                self.get_logger().info('Robot is outside the tool changer')
        else:
            self.get_logger().error(f'Service call failed {future.exception()}')


    #-------------------------------------------------------------------------------------------------------------------------------#
    def pickup_tray(self, robot, tray_id , tray_pose , tray_table):
        """
        Picks up a tray of the specified type.

        Args:
            node (rclpy.node.Node): ROS node for the service call
            tray_type (str): The type of tray to pick up
        """

        # Construct the request message
        request = PickupTray.Request()
        if robot == 'floor_robot':
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError ("Invalid robot name")
        request.tray_id = tray_id
        request.tray_pose = tray_pose
        request.tray_station = tray_table
        # Send the request to the service
        future = self._pickup_tray.call_async(request)

        # Wait for the future to complete and handle any exceptions
        try:
            rclpy.spin_until_future_complete(self, future)
        except KeyboardInterrupt:
            # User interrupted the program
            self.get_logger().info('Service call interrupted')
            return
        except Exception as e:
            self.get_logger().error(f'Service call failed: {str(e)}')
            return

        # Check the result of the service call
        if future.result() is not None:
            response = future.result()
            if response.success:
                self.get_logger().info(f'Tray {tray_id} picked up successfully')
                self.enable_gripper(True)
            else:
                self.get_logger().error(f'Failed to pick up tray {tray_id}: {response.message}')
        else:
            self.get_logger().error('Service call failed: no response')


    #-------------------------------------------------------------------------------------------------------------------------------#
    def move_robot_home(self, robot_name):
        '''Move one of the robots to its home position.

        Arguments:
            robot_name -- Name of the robot to move home
        '''
        request = Trigger.Request()

        if robot_name == 'floor_robot':
            if not self._go_home.wait_for_service(timeout_sec=1.0):
                self.get_logger().error('Robot commander node not running')
                return

            future = self._go_home.call_async(request)
        else:
            self.get_logger().error(f'Robot name: ({robot_name}) is not valid')
            return
        
        # Wait until the service call is completed
        rclpy.spin_until_future_complete(self, future)

        if future.result().success:
            self.get_logger().info(f'Moved {robot_name} to home position')
        else:
            self.get_logger().warn(future.result().message)

 
    #-------------------------------------------------------------------------------------------------------------------------------#
        
    def move_tray_to_agv(self, robot, tray_pose, agv) :
        self.get_logger().info('Move tray to AGV service called')

        # Create request message
        request = MoveTrayToAGV.Request()
        if robot == 'floor_robot':
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError ("Invalid robot name")

        request.tray_pose = tray_pose
        request.agv = agv

        # Send request and wait for response
        future = self._move_tray_to_agv.call_async(request)
        rclpy.spin_until_future_complete(self, future)

        # Check for errors in the response
        response = future.result()
        if response is None:
            self.get_logger().error('Failed to move tray to AGV')
            return
        if not response.success:
            self.get_logger().error('Failed to move tray to AGV: {}'.format(response.error_message))
            return

        self.get_logger().info('Tray successfully moved to AGV')


    #-------------------------------------------------------------------------------------------------------------------------------#
    def place_tray_on_agv(self, robot, tray_id: int, agv):
        self.get_logger().info('Place the tray on AGV, when service called')

        # Create request message
        request = PlaceTrayOnAGV.Request()
        if robot == 'floor_robot':
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError ("Invalid robot name")
        
        request.tray_id = tray_id
        request.agv = agv

        # Send request and wait for response
        future = self._place_tray_on_agv_client.call_async(request)
        rclpy.spin_until_future_complete(self, future)

        # Check for errors in the response
        response = future.result()
        if response is None:
            self.get_logger().error('Failed to place the tray on AGV')
            return
        if not response.success:
            self.get_logger().error('Failed to place the tray on AGV: {}'.format(response.error_message))
            return

        self.get_logger().info('Tray successfully placed on AGV')
        self.enable_gripper(False)
    
    #-------------------------------------------------------------------------------------------------------------------------------#

    def retract_from_agv(self, robot, agv_id:int):
        self.get_logger().info('Retract from the AGV, when service called')
        request = RetractFromAGV.Request()
        if robot == 'floor_robot':
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError("Invalid Robot name")
        
        request.agv = agv_id
        # Send request and wait for response
        future = self._retract_from_agv.call_async(request)
        rclpy.spin_until_future_complete(self, future)

        # Check for errors in the response
        response = future.result()
        if response is None:
            self.get_logger().error('Failed to retract from AGV')
            return
        if not response.success:
            self.get_logger().error('Failed to retract the tray on AGV: {}'.format(response.error_message))
            return

        self.get_logger().info('Retracted Successfully')

    #-------------------------------------------------------------------------------------------------------------------------------#
  
    def pickup_part(self, robot, part_pose, part_type, part_color, bin_side):
        self.get_logger().info('Retract from the AGV, when service called')

        request = PickupPart.Request()
        if robot == "floor_robot":
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError('Invalid Robot name')
        
        request.part_pose = part_pose
        request.part_type = part_type
        request.part_color = part_color
        request.bin_side = bin_side
        # Send request and wait for response
        future = self._pickup_part.call_async(request)
        rclpy.spin_until_future_complete(self, future)

        # Check for errors in the response
        response = future.result()
        if response is None:
            self.get_logger().error('Failed to pick up the part from AGV')
            return
        if not response.success:
            self.get_logger().error('Failed to pick up : {}'.format(response.error_message))
            return

        self.get_logger().info('Picked up part Successfully')
        self.enable_gripper(True)

    #-------------------------------------------------------------------------------------------------------------------------------#
    def move_part_to_agv(self, robot, part_pose, agv, quadrant):
        self.get_logger().info('Retract from the AGV, when service called')

        request = MovePartToAGV.Request()
        if robot == 'floor_robot':
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError('Invalid Robot name')
        request.part_pose = part_pose
        request.quadrant = quadrant
        request.agv = agv

        future = self._move_part_to_agv.call_async(request)
        rclpy.spin_until_future_complete(self, future)

        # Check for errors in the response
        response = future.result()
        if response is None:
            self.get_logger().error('Failed to move the part above the AGV')
            return
        if not response.success:
            self.get_logger().error('Failed to move the part : {}'.format(response.error_message))
            return

        self.get_logger().info('Moved the part Successfully')

    #-------------------------------------------------------------------------------------------------------------------------------#
    def place_part_in_tray(self, robot, agv, quadrant):
        self.get_logger().info('Place the part in tray, when service called')

        request = PlacePartInTray.Request()
        if robot == 'floor_robot':
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError('Invalid Robot name')
        request.agv = agv
        request.quadrant = quadrant
        future = self._place_part_in_tray.call_async(request)
        rclpy.spin_until_future_complete(self, future)

        # Check for errors in the response
        response = future.result()
        if response is None:
            self.get_logger().error('Unfortunately failed to place the part in tray')
            return
        if not response.success:
            self.get_logger().error('Failed to place the part in tray : {}'.format(response.error_message))
            return

        self.get_logger().info('Placed the part in Tray Successfully')
        self.enable_gripper(False)

    #-------------------------------------------------------------------------------------------------------------------------------#

    def agv_lock_tray(self, agv_id: int):
        # Create the request message
        request = Trigger.Request()
        

        # Call the lock_tray service
        if agv_id[3] == '1':
            future = self._agv1_lock_tray.call_async(request)
        elif agv_id[3] == '2':
            future = self._agv2_lock_tray.call_async(request)
        elif agv_id[3] == '3':
            future = self._agv3_lock_tray.call_async(request)
        else:
            future = self._agv4_lock_tray.call_async(request)

        # Wait for the response
        rclpy.spin_until_future_complete(self, future)

        if future.result() is not None:
            response = future.result()
            if response.success:
                self.get_logger().info(f'Tray locked on AGV {agv_id}')
                return True
            else:
                self.get_logger().error(f'Oops forgot to lock tray on AGV {agv_id}')
                return False
        else:
            self.get_logger().error(f'The Lock_agv service is not called properly: {future.exception()}')
            return False
        
    #-------------------------------------------------------------------------------------------------------------------------------#
    def move_agv(self, agv_id):
        self.get_logger().info('Move agv, when service called')

        request = MoveAGV.Request()
        request.location = 3
        future = None
        if agv_id[3] == '1':
            future = self._move_agv1.call_async(request)
            self.get_logger().info("AGV MOVING %d" % int(agv_id[3]))
        elif agv_id[3] == '2':
            future = self._move_agv2.call_async(request)
            self.get_logger().info("AGV MOVING %d" % int(agv_id[3]))
        elif agv_id[3] == '3':
            future = self._move_agv3.call_async(request)
            self.get_logger().info("AGV MOVING %d" % int(agv_id[3]))
        else:
            future = self._move_agv4.call_async(request)
            self.get_logger().info("AGV MOVING %d" % int(agv_id[3]))

        # future = self._move_agv.call_async(request)
        rclpy.spin_until_future_complete(self, future)

        # Check for errors in the response
        response = future.result()
        if response is None:
            self.get_logger().error('Unfortunately failed to move the agv')
            return
        if not response.success:
            self.get_logger().error('Failed to move the agv : {}'.format(response.error_message))
            return

        self.get_logger().info('Successfully moved the agv')
    #-------------------------------------------------------------------------------------------------------------------------------#
    def robot_change_gripper(self, gripper_type):
        request = ChangeGripper.Request()
        request.gripper_type = gripper_type

        future = self._robot_change_gripper.call_async(request)

        rclpy.spin_until_future_complete(self, future)

        if future.result() is not None:
            response = future.result()
            self.get_logger().info(f'Successfully changed gripper to {gripper_type}')
        else:
            self.get_logger().info('Service call failed')
    

    #-------------------------------------------------------------------------------------------------------------------------------#

    def enable_gripper(self, enable):
        """Enable the gripper of the robot."""
        request = VacuumGripperControl.Request()
        request.enable = enable

        future = self._enable_gripper.call_async(request)

        rclpy.spin_until_future_complete(self, future)

        if future.result() is not None:
            response = future.result()
            if response.success:
                self.get_logger().info('Gripper enabled.')
            else:
                self.get_logger().info(f'Service call not completed.')
        


def main(args=None):
    '''
    Main function to create a ROS2 node

    Args:
        args (Any, optional): ROS2 arguments. Defaults to None.
    '''
    rclpy.init(args=args)
    node = ClientNode('subscriber_node')
    executor = MultiThreadedExecutor()
    executor.add_node(node)
    try:
        node.get_logger().info('Beginning demo, end with CTRL-C')
        executor.spin()
    except KeyboardInterrupt:
        node.get_logger().info('KeyboardInterrupt, shutting down.\n')
    node.destroy_node()

    rclpy.shutdown()

if __name__ == '__main__':
    main()
