# ========================================
# ENPM809E Spring 2023: Application for python programming
# rwa4
# ========================================
# Author: Rashmi Kapu (rashmik@umd.edu)
# UID: 119461754
# Directory ID: rashmik

# Author: Rishab Namdev (rnamdev@umd.edu)
# UID: 119480977
# Directory ID: rishabnamdev
# ========================================
# Press CTRL+C for exit




from ariac_msgs.srv import MoveAGV, ChangeGripper, VacuumGripperControl
from std_srvs.srv import Trigger
import rclpy
import yaml
from rclpy.node import Node
from tf_package.tf_node import *
from ariac_msgs.msg import Order
from ariac_msgs.msg import AdvancedLogicalCameraImage
from example_interfaces.msg import String
from rclpy.executors import SingleThreadedExecutor, MultiThreadedExecutor
from rclpy.callback_groups import MutuallyExclusiveCallbackGroup, ReentrantCallbackGroup
from rclpy.qos import QoSDurabilityPolicy, QoSHistoryPolicy, QoSReliabilityPolicy
from rclpy.qos import QoSProfile
from competitor_interfaces.msg import Robots as RobotsMsg
from competitor_interfaces.srv import (EnterToolChanger, ExitToolChanger, PickupTray, MoveTrayToAGV, MovePartToAGV, PlacePartInTray, RetractFromAGV, PickupPart, PlaceTrayOnAGV)
from ariac_msgs.msg import CompetitionState
from ament_index_python.packages import get_package_share_directory
import os

parameter_file = os.path.join(
    get_package_share_directory('rwa4_17'),
    'config',
    'order.yaml')

class ClientNode(Node):
    '''
    Simple class to create a ROS2 node

    Args:
        Node (class): ROS2 node class
    '''

    def __init__(self, node_name):
        super().__init__(node_name)
        service_group = MutuallyExclusiveCallbackGroup()
        timer_group = MutuallyExclusiveCallbackGroup()
        self.tf = TfListener('tray', 'world')
        self.order = False
        self._counter1 = True
        self._counter2 = True
        self.order_dict = {}
        
        qos_profile = QoSProfile(depth=10)
        qos_profile.reliability = QoSReliabilityPolicy.BEST_EFFORT
        qos_profile.durability = QoSDurabilityPolicy.VOLATILE
        # self.id = None
        # self.type = None
        # self.priority = None
        # self.agv = None
        # self.tray_id = None
        # self.dest = None
        # self.parts = None
        
        #a list to keep track of getting just 1 message from cameras
        self._message_list1 = []
        self._message_list2 = []  
        self._message_list3 = []  
        self._message_list4 = []  
        self._message_list5 = []
        #parameter
        self.order_id = self.read_yaml(parameter_file)['rwa4']['ros__parameters']['order_id']
        self._kit_completed = False
        self._competition_state = None
        
        self.get_logger().info(f'{node_name} node running')
        #-----------------------------
        # self._start_competition_client = self.create_client(Trigger, '/start_competition', callback_group=service_group)
        self._enter_tool_changer_client = self.create_client(EnterToolChanger, '/enter_tool_changer', callback_group=service_group)
        self._exit_tool_changer_client = self.create_client(ExitToolChanger, '/competitor/floor_robot/exit_tool_changer', callback_group=service_group)
        self._go_home = self.create_client(Trigger, '/move_floor_robot_home', callback_group=service_group)
        self._pickup_tray = self.create_client(PickupTray, '/competitor/floor_robot/pickup_tray', callback_group=service_group)
        self._move_tray_to_agv = self.create_client(MoveTrayToAGV, '/competitor/floor_robot/move_tray_to_agv', callback_group=service_group)
        self._place_tray_on_agv = self.create_client(PlaceTrayOnAGV, 'competitor/floor_robot/place_tray_on_agv', callback_group=service_group)
        self._move_tray_to_agv =self.create_client(MoveTrayToAGV, 'competitor/floor_robot/move_tray_to_agv', callback_group=service_group)
        self._retract_from_agv = self.create_client(RetractFromAGV, 'competitor/floor_robot/retract_from_agv',callback_group=service_group)
        self._pickup_part = self.create_client(PickupPart, 'competitor/floor_robot/pickup_part', callback_group=service_group)
        self._move_part_to_agv = self.create_client(MovePartToAGV,'competitor/floor_robot/move_part_to_agv', callback_group=service_group)
        self._place_part_in_tray = self.create_client(PlacePartInTray,'competitor/floor_robot/place_part_in_tray', callback_group=service_group)
        self._agvX_lock_tray =self.create_client(Trigger, '/ariac/agv3_lock_tray', callback_group=service_group)
        self._move_agv = self.create_client(MoveAGV, '/ariac/move_agv3', callback_group=service_group)
        self._robot_change_gripper = self.create_client(ChangeGripper, '/ariac/floor_robot_change_gripper', callback_group=service_group)
        self._enable_gripper = self.create_client(VacuumGripperControl, 'ariac/floor_robot_enable_gripper', callback_group=service_group)
        # Service client for entering the gripper slot
        self._goto_tool_changer_client = self.create_client(
            EnterToolChanger, '/competitor/floor_robot/enter_tool_changer',
            callback_group=service_group)
        self._competition_started = False

        self._robot_action_timer = self.create_timer(1, self._robot_action_timer_callback,
                                                     callback_group=timer_group)
        #-------------------------------------
        self._subscriber_order = self.create_subscription(Order,'/ariac/orders',
                                                     self._subscriber1_callback,
                                                     10)
        
        self._subscriber_camera1 = self.create_subscription(AdvancedLogicalCameraImage,'/ariac/sensors/table1_camera/image',
                                                     self._subscriber2_callback,
                                                     qos_profile)
        
        self._subscriber_camera2 = self.create_subscription(AdvancedLogicalCameraImage,'/ariac/sensors/table2_camera/image',
                                                     self._subscriber3_callback,
                                                     qos_profile)
        

        self._subscriber_camera3 = self.create_subscription(AdvancedLogicalCameraImage,'/ariac/sensors/left_bins_camera/image',
                                                     self._subscriber4_callback,
                                                     qos_profile)
        

        self._subscriber_camera4 = self.create_subscription(AdvancedLogicalCameraImage,'/ariac/sensors/right_bins_camera/image',
                                                     self._subscriber5_callback,
                                                     qos_profile)
        
        self.create_subscription(CompetitionState, '/ariac/competition_state',
                                 self._competition_state_cb, 1)
       

#-----------------------------------------------------------------------------

    def read_yaml(self, path):
        with open(path, "r") as stream:
            try:
                return yaml.safe_load(stream)
            except yaml.YAMLError:
                self.get_logger().error("Unable to read configuration file")
                return {}
            
    
    def _subscriber1_callback(self,msg):
        """
            Callback function to manage the incoming messages from the topic /ariac/orders.

            Args:
                msg: contains announcement that gazebo makes for the order.

            Returns:
                None

            Behavior:
                Splits the information from the message and stores it in class variables

        """   
       
        self.id = msg.id
        self.priority = msg.priority
        self.type = msg.type
        self.agv_number = msg.kitting_task.agv_number
        self.tray_id = msg.kitting_task.tray_id
        self.destination = msg.kitting_task.destination
        self.parts = []
        for part in msg.kitting_task.parts: 
                part_dict = { # dict for each part
                    'color': part.part.color, 
                    'type': part.part.type,
                    'quadrant': part.quadrant
                }
                self.parts.append(part_dict)
            # self.color = msg.color
            # self.color = msg.type
        self.get_logger().info("\n-----------------Reading data gazebo--------------------\n")
        self.get_logger().info(f"\nid = {self.id}\ntype = {self.type}\npriority = {self.priority}\nkitting task:\nagv_number = {self.agv_number}\ntray_id = {self.tray_id}\ndest = {self.destination}\nparts:\n {self.parts}")
        self._message_list1.append(msg)
        if self.order_id is not None:
            self.get_logger().info(f"Order ID to be implemented is: {self.order_id}")
        else:
            self.get_logger().error("Failed to get parameter 'order_id'")





    def _subscriber2_callback(self,msg):
        """
    Incoming messages from the table 1 camera topic.

    Args:
        msg: Contains information about the camera readings i.e the camera coordinates of the tray.

    Returns:
        None

    Behavior:
        Extracts information from the message object and sets instance variables.
        Calculates the transformation between the tray and the sensor pose with respect to world coordinates.
        Prints the data (position, orientation etc)

    """
        if len(self._message_list2) < 1 :
            self.get_logger().info(f"\n---------Reading data Camera 1 --------\n{msg}")
            self._data_cam1 = msg
            # self.get_logger().info(f"\n---------msg : {msg} --------\n")
            self._cam1_tray = self._data_cam1.tray_poses
            self.tray1_pose_position_x = self._cam1_tray[0].pose.position.x
            self.tray1_pose_position_y = self._cam1_tray[0].pose.position.y
            self.tray1_pose_position_z = self._cam1_tray[0].pose.position.z
            self.tray1_pose_orientation_x = self._cam1_tray[0].pose.orientation.x
            self.tray1_pose_orientation_y = self._cam1_tray[0].pose.orientation.y
            self.tray1_pose_orientation_z = self._cam1_tray[0].pose.orientation.z
            self.tray1_pose_orientation_w = self._cam1_tray[0].pose.orientation.w
            self._cam1_sensor = self._data_cam1.sensor_pose
            self.get_logger().info(f"\nTray poses:\nid={self._cam1_tray[0].id}\nPosition:\nx={self._cam1_tray[0].pose.position.x}\ny={self._cam1_tray[0].pose.position.y}\nz={self._cam1_tray[0].pose.position.z}\norientation:\nx={self._cam1_tray[0].pose.orientation.x}\ny={self._cam1_tray[0].pose.orientation.y}\nz={self._cam1_tray[0].pose.orientation.z}")
            self.get_logger().info(f"\nSensor poses:\nPosition:\nx={self._cam1_sensor.position.x}\ny={self._cam1_sensor.position.y}\nz={self._cam1_sensor.position.z}\norientation:\nx={self._cam1_sensor.orientation.x}\ny={self._cam1_sensor.orientation.y}\nz={self._cam1_sensor.orientation.z}")
            self.get_logger().info("\n\n\n----------TRANSFORMING TRAY1 to World Coordinate System------------\n\n\n")
            self.trans1 = self._transform(self._cam1_tray[0].pose,self._cam1_sensor)
            self.get_logger().info(f"\n--------------TRANSFORMED POSES-------------\n{self.trans1}")
            
            
            self._message_list2.append(msg)
        # if len(self._message_list2)!=0 and len(self._message_list3)!=0 and len(self._message_list4)!=0 and len(self._message_list5)!=0:
        #          _robot_action_timer_callback()
            
        
    def _subscriber3_callback(self,msg):
        """
    Incoming messages from the table 2 camera topic.

    Args:
        msg: Contains information about the camera readings i.e the camera coordinates of the tray.

    Returns:
        None

    Behavior:
        Extracts information from the message object and sets instance variables.
        Calculates the transformation between the tray and the sensor pose with respect to world coordinates.
        Prints the data (position, orientation etc)

    """
        if len(self._message_list3) < 1 :
            self.get_logger().info(f"\n-----------------Reading data Camera 2 -------------------\n ")
            self._data_cam2 = msg
            self._cam2_tray = self._data_cam2.tray_poses
            self.tray2_pose_position_x = self._cam2_tray[0].pose.position.x
            self.tray2_pose_position_y = self._cam2_tray[0].pose.position.y
            self.tray2_pose_position_z = self._cam2_tray[0].pose.position.z
            self.tray2_pose_orientation_x = self._cam2_tray[0].pose.orientation.x
            self.tray2_pose_orientation_y = self._cam2_tray[0].pose.orientation.y
            self.tray2_pose_orientation_z = self._cam2_tray[0].pose.orientation.z
            self.tray2_pose_orientation_w = self._cam2_tray[0].pose.orientation.w
            self._cam2_sensor = self._data_cam2.sensor_pose
            self.get_logger().info(f"\nTray poses:\nid={self._cam2_tray[0].id}\nPosition:\nx={self._cam2_tray[0].pose.position.x}\ny={self._cam2_tray[0].pose.position.y}\nz={self._cam2_tray[0].pose.position.z}\norientation:\nx={self._cam2_tray[0].pose.orientation.x}\ny={self._cam2_tray[0].pose.orientation.y}\nz={self._cam2_tray[0].pose.orientation.z}")
            self.get_logger().info(f"\nSensor poses:\nPosition:\nx={self._cam2_sensor.position.x}\ny={self._cam2_sensor.position.y}\nz={self._cam2_sensor.position.z}\norientation:\nx={self._cam2_sensor.orientation.x}\ny={self._cam2_sensor.orientation.y}\nz={self._cam2_sensor.orientation.z}")
            # self.get_logger().info(f"cam2_tray = {self._cam2_sensor.pose.orientation}")
            self.get_logger().info("\n\n\n----------TRANSFORMING TRAY2 to World Coordinate System------------\n\n\n")
            self.trans2 = self._transform(self._cam2_tray[0].pose,self._cam2_sensor)
            self.get_logger().info(f"\n--------------TRANSFORMED POSES-------------\n{self.trans2}")
                  
            self._message_list3.append(msg)
        # if len(self._message_list2)!=0 and len(self._message_list3)!=0 and len(self._message_list4)!=0 and len(self._message_list5)!=0:
        #          _robot_action_timer_callback()

    def _subscriber4_callback(self,msg):
        """
    Incoming messages from the left bins camera topic.

    Args:
        msg: Contains information about the camera readings i.e the camera coordinates of the parts.

    Returns:
        None

    Behavior:
        Extracts information from the message object and sets instance variables.
        Calculates the transformation between the part and the sensor pose with respect to world coordinates.
        Prints the data (position, orientation )

    """
        
        
        if len(self._message_list4) < 1 :
            self.left_bin = msg
            self.left_bins_info = []
            for i in range(len(self.left_bin.part_poses)):
                part_info = {
                    'type': self.left_bin.part_poses[i].part.type,
                    'color': self.left_bin.part_poses[i].part.color,
                    'pose': self.left_bin.part_poses[i].pose
                }
                
                part_info["pose"] = self.tf._multiply_pose(self.left_bin.sensor_pose, part_info['pose'])
                #store info of all parts in the left bin
                self.left_bins_info.append(part_info)

            self.get_logger().info(f"\n-----------------Reading data Camera 3 -------------------\n{msg}")
            self._data_cam3 = msg
            self._cam3_part = self._data_cam3.part_poses
            self._cam3_sensor = self._data_cam3.sensor_pose
            self.get_logger().info(f"\nPart poses : \nPart:\nColor:  {self._cam3_part[0].part.color}\nType {self._cam3_part[0].part.type}")
            self.get_logger().info(f"\nPose:\nPosition:\nx:{self._cam3_part[0].pose.position.x}\ny:{self._cam3_part[0].pose.position.y}\nz:{self._cam3_part[0].pose.position.z}\nOrientation: \nx:{self._cam3_part[0].pose.orientation.x}\ny:{self._cam3_part[0].pose.orientation.y}\nz:{self._cam3_part[0].pose.orientation.z}")
            self.get_logger().info(f"\nSensor poses:\nPosition:\nx={self._cam3_sensor.position.x}\ny={self._cam3_sensor.position.y}\nz={self._cam3_sensor.position.z}\norientation:\nx={self._cam3_sensor.orientation.x}\ny={self._cam3_sensor.orientation.y}\nz={self._cam3_sensor.orientation.z}")
            
            #self.trans3 = self._transform(self._cam3_part[0].pose,self._cam3_sensor)
            #self.get_logger().info(f"\n--------------TRANSFORMED POSES-------------\n{self.trans3}")
      

            self._message_list4.append(msg)
        # if len(self._message_list2)!=0 and len(self._message_list3)!=0 and len(self._message_list4)!=0 and len(self._message_list5)!=0:
        #          _robot_action_timer_callback()   

    def _subscriber5_callback(self,msg):
        """
    Incoming messages from the right bins camera topic.

    Args:
        msg: Contains information about the camera readings i.e the camera coordinates of the parts.

    Returns:
        None

    Behavior:
        Extracts information from the message object and sets instance variables.
        Calculates the transformation between the part and the sensor pose with respect to world coordinates.
        Prints the data (position, orientation )

    """
        if len(self._message_list5) < 1 :
            self.right_bin = msg
            self.right_bins_info = []
            for i in range(len(self.right_bin.part_poses)):
                part_info = {
                    'type': self.right_bin.part_poses[i].part.type,
                    'color': self.right_bin.part_poses[i].part.color,
                    'pose': self.right_bin.part_poses[i].pose
                }
                part_info["pose"] = self.tf._multiply_pose(self.right_bin.sensor_pose, part_info['pose'])
                #store poses of all parts on the right bin
                self.right_bins_info.append(part_info)
            self.get_logger().info(f"\n\n---------Reading data Camera 4-----------\n \n")
            self._data_cam4 = msg
            self._cam4_part = self._data_cam4.part_poses
            self._cam4_sensor = self._data_cam4.sensor_pose
            self.purple_pump_pose_position_x =  self._cam4_part[0].pose.position.x
            # self.get_logger().info(f"\nColor {self._cam4_part[0].part.color}")
            # self.get_logger().info(f"\nType {self._cam4_part[0].part.type}")
            self.get_logger().info(f"\nPart poses : \nPart:\nColor:  {self._cam4_part[0].part.color}\nType {self._cam4_part[0].part.type}")
            self.get_logger().info(f"\nPose:\nPosition:\nx:{self._cam4_part[0].pose.position.x}\ny:{self._cam4_part[0].pose.position.y}\nz:{self._cam4_part[0].pose.position.z}\nOrientation: \nx:{self._cam4_part[0].pose.orientation.x}\ny:{self._cam4_part[0].pose.orientation.y}\nz:{self._cam4_part[0].pose.orientation.z}")
            self.get_logger().info(f"\nSensor poses:\nPosition:\nx={self._cam4_sensor.position.x}\ny={self._cam4_sensor.position.y}\nz={self._cam4_sensor.position.z}\norientation:\nx={self._cam4_sensor.orientation.x}\ny={self._cam4_sensor.orientation.y}\nz={self._cam4_sensor.orientation.z}")
            self.trans4 = self._transform(self._cam4_part[0].pose,self._cam4_sensor)
            self.get_logger().info(f"\n--------------TRANSFORMED POSES-------------\n{self.trans4}")
            self._message_list5.append(msg)
            self.get_logger().info(f"Part info: {part_info}")
        # if len(self._message_list2)!=0 and len(self._message_list3)!=0 and len(self._message_list4)!=0 and len(self._message_list5)!=0:
        #          _robot_action_timer_callback()
    #-------------------------------------------------------------------------------------------
    def _transform (self, pose1, pose2):
        """
    Function to calculate the transformation between two poses/frames.

    Args:
        pose1: The first pose (either tray or part pose).
        pose2: The second pose (sensor pose).

    Returns:
        A transformation pose object.

    Behavior:
        Uses multiplypose() from TFListener to do the transformation between two frames, it can be from world pose to camera/sensor pose

    """

        return self.tf._multiply_pose(pose1, pose2) 
    

    #-----------------------------------------------------------------------------------------

    def _robot_action_timer_callback(self):
        '''
        Callback for the timer that triggers the robot actions
        '''

        if not self._competition_started and len(self._message_list2)!=0 and len(self._message_list3)!=0 and len(self._message_list4)!=0 and len(self._message_list5)!=0: #and self._competition_state == CompetitionState.READY :
        #     self.start_competition()

            self.get_logger().info(f"starting competition Hurrey!")
            
        # else :
        #     return 
            # move robot home
            self.move_robot_home("floor_robot")

        # change gripper type
            #self.goto_tool_changer("floor_robot", "kts1", "trays")

            self.exit_tool_changer("floor_robot" , "kts1" , "trays")
       # self._message_list1                       
            tray = self._message_list1[self.order_id].kitting_task.tray_id
            part1 = self._message_list1[self.order_id].kitting_task.parts.part[0]
            part2 = self._message_list1[self.order_id].kitting_task.parts.part[1]

        # if (int(tray)==3) :
        #     #move to left tray
            
        #     #keep the tray on that table
        # else :
        #     #move to right tray
            
        # if int(part1.color) == 2 or int(part1.color) == 3 :
        #     #left bins camera
        #     #go to the bins
        #     #pick block from the quadrant
        #     #go to tray
        #     #place the block

        # else :
        #     #right bins camera
        #     #go to the bins
        #     #pick block from the quadrant
        #     #go to tray
        #     #place the block

        # if int(part2.color) == 2 or int(part2.color) == 3 :
        #     #left bins camera
        #     #go to the bins
        #     #pick block from the quadrant
        #     #go to tray
        #     #place the block

        # else :
        #     #right bins camera
        #     #go to the bins
        #     #pick block from the quadrant
        #     #go to tray
        #     #place the block


        # exit the callback if the kit is completed
        if self._kit_completed:
            return

        
        

        
            
                               



        # to ignore function calls in this callback
        self._kit_completed = True


    #----------------------------------------------------------------------------------------------------
    def goto_tool_changer(self, robot, station, gripper_type):
        '''
        Move the end effector inside the gripper slot.

        Args:
            station (str): Gripper station name
            gripper_type (str): Gripper type

        Raises:
            KeyboardInterrupt: Exception raised when the user presses Ctrl+C
        '''

        self.get_logger().info('Move inside gripper slot service called')

        request = EnterToolChanger.Request()

        if robot == "floor_robot":
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError('Invalid robot name')

        request.station = station
        request.gripper_type = gripper_type

        future = self._goto_tool_changer_client.call_async(request)

        try:
            rclpy.spin_until_future_complete(self, future)
        except KeyboardInterrupt as kb_error:
            raise KeyboardInterrupt from kb_error

        if future.result() is not None:
            response = future.result()
            if response:
                self.get_logger().info('Robot is at the tool changer')
        else:
            self.get_logger().error(f'Service call failed {future.exception()}')
            self.get_logger().error('Unable to move the robot to the tool changer')

    #-------------------------------------------------------------------------------------------------------
    def _competition_state_cb(self, msg: CompetitionState):
        '''
        /ariac/competition_state topic callback function

        Args:
            msg (CompetitionState): CompetitionState message
        '''
        self._competition_state = msg.competition_state
#-------------------------------------------------------------------------------------------------------------------------------#
    def start_competition(self):
        '''
        Start the competition
        '''
        self.get_logger().info('Waiting for competition state READY')

        request = Trigger.Request()
        future = self._start_competition_client.call_async(request)

        # Wait until the service call is completed
        rclpy.spin_until_future_complete(self, future)

        if future.result().success  :
            self.get_logger().info('Started competition.')
            self._competition_started = True
        else:
            self.get_logger().warn('Unable to start competition')


#-------------------------------------------------------------------------------------------------------------------------------#
    def enter_tool_changer(self, robot, station, gripper_type):
        '''
        Move the end effector inside the gripper slot.

        Args:
            station (str): Gripper station name
            gripper_type (str): Gripper type

        Raises:
            KeyboardInterrupt: Exception raised when the user presses Ctrl+C
        '''

        self.get_logger().info('Move inside gripper slot service called')

        request = EnterToolChanger.Request()

        if robot == "floor_robot":
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError('Invalid robot name')

        request.station = station
        request.gripper_type = gripper_type

        future = self._enter_tool_changer_client.call_async(request)

        try:
            rclpy.spin_until_future_complete(self, future)
        except KeyboardInterrupt as kb_error:
            raise KeyboardInterrupt from kb_error

        if future.result() is not None:
            response = future.result()
            if response:
                self.get_logger().info('Robot is at the tool changer')
        else:
            self.get_logger().error(f'Service call failed {future.exception()}')
            self.get_logger().error('Unable to move the robot to the tool changer')



#-------------------------------------------------------------------------------------------------------------------------------#
    def exit_tool_changer(self, robot, station, gripper_type):
        '''
        Move the end effector outside the gripper slot.

        Args:
            robot (str): Robot name
            station (str): Gripper station name
            gripper_type (str): Gripper type

        Raises:
            KeyboardInterrupt: Exception raised when the user presses Ctrl+C
        '''

        self.get_logger().info('Move outside gripper slot service called')

        request = ExitToolChanger.Request()

        if robot == "floor_robot":
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError('Invalid robot name')

        request.station = station
        request.gripper_type = gripper_type

        future = self._exit_tool_changer_client.call_async(request)

        try:
            rclpy.spin_until_future_complete(self, future)
        except KeyboardInterrupt as kb_error:
            raise KeyboardInterrupt from kb_error

        if future.result() is not None:
            response = future.result()
            if response:
                self.get_logger().info('Robot is outside the tool changer')
        else:
            self.get_logger().error(f'Service call failed {future.exception()}')
            self.get_logger().error('Unable to move the robot outside the tool changer')


#-------------------------------------------------------------------------------------------------------------------------------#
    def pickup_tray(self, robot, tray_type: str):
        """
        Picks up a tray of the specified type.

        Args:
            node (rclpy.node.Node): ROS node for the service call
            tray_type (str): The type of tray to pick up
        """

        # Construct the request message
        request = PickupTray.Request()
        if robot == 'floor_robot':
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError ("Invalid robot name")
        request.tray_type = tray_type

        # Send the request to the service
        future = self._pickup_tray.call_async(request)

        # Wait for the future to complete and handle any exceptions
        try:
            rclpy.spin_until_future_complete(self, future)
        except KeyboardInterrupt:
            # User interrupted the program
            self.get_logger().info('Service call interrupted')
            return
        except Exception as e:
            self.get_logger().error(f'Service call failed: {str(e)}')
            return

        # Check the result of the service call
        if future.result() is not None:
            response = future.result()
            if response.success:
                self.get_logger().info(f'Tray {tray_type} picked up successfully')
            else:
                self.get_logger().error(f'Failed to pick up tray {tray_type}: {response.message}')
        else:
            self.get_logger().error('Service call failed: no response')


#-------------------------------------------------------------------------------------------------------------------------------#
    def move_robot_home(self, robot_name):
        '''Move one of the robots to its home position.

        Arguments:
            robot_name -- Name of the robot to move home
        '''
        request = Trigger.Request()

        if robot_name == 'floor_robot':
            if not self._go_home.wait_for_service(timeout_sec=1.0):
                self.get_logger().error('Robot commander node not running')
                return

            future = self._go_home.call_async(request)
        else:
            self.get_logger().error(f'Robot name: ({robot_name}) is not valid')
            return
        
        # Wait until the service call is completed
        rclpy.spin_until_future_complete(self, future)

        if future.result().success:
            self.get_logger().info(f'Moved {robot_name} to home position')
        else:
            self.get_logger().warn(future.result().message)

#-------------------------------------------------------------------------------------------------------------------------------#
        
    def move_tray_to_agv(self, robot, tray_id: int, agv) :
        self.get_logger().info('Move tray to AGV service called')

        # Create request message
        request = MoveTrayToAGV.Request()
        if robot == 'floor_robot':
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError ("Invalid robot name")

        request.tray_id = tray_id
        request.agv = agv

        # Send request and wait for response
        future = self._move_tray_to_agv.call_async(request)
        rclpy.spin_until_future_complete(self.node, future)

        # Check for errors in the response
        response = future.result()
        if response is None:
            self.get_logger().error('Failed to move tray to AGV')
            return
        if not response.success:
            self.get_logger().error('Failed to move tray to AGV: {}'.format(response.error_message))
            return

        self.get_logger().info('Tray successfully moved to AGV')


#-------------------------------------------------------------------------------------------------------------------------------#
    def place_tray_on_agv(self,robot,tray_id: int, agv):
        self.get_logger().info('Place the tray on AGV, when service called')

        # Create request message
        request = PlaceTrayOnAGV.Request()
        if robot == 'floor_robot':
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError ("Invalid robot name")
        
        request.tray_id = tray_id
        request.agv = agv

        # Send request and wait for response
        future = self.place_tray_on_agv_client.call_async(request)
        rclpy.spin_until_future_complete(self.node, future)

        # Check for errors in the response
        response = future.result()
        if response is None:
            self.get_logger().error('Failed to place the tray on AGV')
            return
        if not response.success:
            self.get_logger().error('Failed to place the tray on AGV: {}'.format(response.error_message))
            return

        self.get_logger().info('Tray successfully placed on AGV')
    
#-------------------------------------------------------------------------------------------------------------------------------#

    def retract_from_agv(self, robot, agv_id:int):
        logging.info('Retract from the AGV, when service called')
        request = RetractFromAGV.Request()
        if robot == 'floor_robot':
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError("Invalid Robot name")
        
        request.agv_id = agv_id
        # Send request and wait for response
        future = self._retract_from_agv.call_async(request)
        rclpy.spin_until_future_complete(self.node, future)

        # Check for errors in the response
        response = future.result()
        if response is None:
            self.get_logger().error('Failed to retract from AGV')
            return
        if not response.success:
            self.get_logger().error('Failed to retract the tray on AGV: {}'.format(response.error_message))
            return

        logging.info('Retracted Successfully')
#-------------------------------------------------------------------------------------------------------------------------------#
  
    def pickup_part(self, robot, part_type, part_id, part_color):
        logging.info('Retract from the AGV, when service called')

        request = PickupPart.Request()
        if robot == 'floor Robot':
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError('Invalid Robot name')
        
        request.part_type = part_type
        request.part_id = part_id
        request.part_color = part_color
        # Send request and wait for response
        future = self._pickup_part.call_async(request)
        rclpy.spin_until_future_complete(self.node, future)

        # Check for errors in the response
        response = future.result()
        if response is None:
            self.get_logger().error('Failed to pick up the part from AGV')
            return
        if not response.success:
            self.get_logger().error('Failed to pick up : {}'.format(response.error_message))
            return

        logging.info('Pickedup Successfully')
#-------------------------------------------------------------------------------------------------------------------------------#
    def move_part_to_agv(self, robot, part_type, part_id, part_color, agv):
        logging.info('Retract from the AGV, when service called')

        request = MovePartToAGV.Request()
        if robot == 'floor Robot':
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError('Invalid Robot name')
        request.part_type = part_type
        request.part_id = part_id
        request.part_color = part_color
        request.agv = agv

        future = self._move_part_to_agv.call_async(request)
        rclpy.spin_until_future_complete(self.node, future)

        # Check for errors in the response
        response = future.result()
        if response is None:
            self.get_logger().error('Failed to move the part above the AGV')
            return
        if not response.success:
            self.get_logger().error('Failed to move the part : {}'.format(response.error_message))
            return

        logging.info('Moved the part Successfully')
#-------------------------------------------------------------------------------------------------------------------------------#
    def place_part_in_tray(self, robot, quadrant, agv):
        logging.info('Place the part in tray, when service called')

        request = PlacePartInTray.Request()
        if robot == 'floor Robot':
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError('Invalid Robot name')
        request.agv = agv
        request.quadrant = quadrant
        future = self._place_part_in_tray.call_async(request)
        rclpy.spin_until_future_complete(self.node, future)

        # Check for errors in the response
        response = future.result()
        if response is None:
            self.get_logger().error('Unfortunately failed to place the part in tray')
            return
        if not response.success:
            self.get_logger().error('Failed to place the part in tray : {}'.format(response.error_message))
            return

        logging.info('Placed the part Successfully')

#-------------------------------------------------------------------------------------------------------------------------------#

    def agv1_lock_tray(self, robot, tray_id: int, agv_id: int):
        # Create the request message
        request = Trigger.Request()
        if robot == 'floor Robot':
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError('Invalid Robot name')
        request.tray_id = tray_id
        request.agv_id = agv_id

        # Call the lock_tray service
        future = self._agvX_lock_tray.call_async(request)

        # Wait for the response
        rclpy.spin_until_future_complete(self.node, future)

        if future.result() is not None:
            response = future.result()
            if response.success:
                self.get_logger().info(f'Tray {tray_id} locked on AGV {agv_id}')
                return True
            else:
                self.get_logger().error(f'Oops forgot to lock tray {tray_id} on AGV {agv_id}')
                return False
        else:
            self.get_logger().error(f'The Lock_agv service is not called properly: {future.exception()}')
            return False
#-------------------------------------------------------------------------------------------------------------------------------#
    def move_agv1(self, robot, agv_id: int, x: float, y: float, z: float) -> None:
        logging.info('Place the part in tray, when service called')

        request = MoveAGV.Request()
        if robot == 'floor Robot':
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError('Invalid Robot name')
        request = MoveAGV.Request()
        request.position.x = x
        request.position.y = y
        request.position.z = z
        future = self._move_agv.call_async(request)
        rclpy.spin_until_future_complete(self.node, future)

        # Check for errors in the response
        response = future.result()
        if response is None:
            self.get_logger().error('Unfortunately failed move the agv')
            return
        if not response.success:
            self.get_logger().error('Failed to movethe agv : {}'.format(response.error_message))
            return

        logging.info('Successfully moved the agv')
#-------------------------------------------------------------------------------------------------------------------------------#
    def robot_change_gripper(self, robot, gripper_type: str):
        request = ChangeGripper.Request()
        if robot == 'floor_robot':
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError('Invalid Robot name')
        request.gripper_type = gripper_type

        future = self._robot_change_gripper.call_async(request)

        # if not rclpy.ok():
        #     self.get_logger().info('ROS shutdown')
        #     return

        rclpy.spin_until_future_complete(self.node, future)

        if future.result() is not None:
            response = future.result()
            if response.success:
                self.get_logger().info(f'Successfully changed gripper to {gripper_type} for {robot}')
            else:
                self.get_logger().info(f'Failed to change gripper for {robot}')
        else:
            self.get_logger().info('Service call failed')
    

#-------------------------------------------------------------------------------------------------------------------------------#

    def enable_gripper(self, robot, gripper_type):
        """Enable the gripper of the robot."""
        request = VacuumGripperControl.Request()
        if robot == 'floor_robot':
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError('Invalid Robot name')
        request.gripper_type = gripper_type

        future = self._enable_gripper.call_async(request)

        rclpy.spin_until_future_complete(self.node, future)

        if future.result() is not None:
            response = future.result()
            if response.success:
                self.get_logger().info('Gripper enabled.')
            else:
                self.get_logger().info(f'Service call not completed.')
        


def main(args=None):
    '''
    Main function to create a ROS2 node

    Args:
        args (Any, optional): ROS2 arguments. Defaults to None.
    '''
    rclpy.init(args=args)
    node = ClientNode('subscriber_node')
    executor = MultiThreadedExecutor()
    executor.add_node(node)
    try:
        print()
        node.get_logger().info('Beginning demo, end with CTRL-C')
        executor.spin()
    except KeyboardInterrupt:
        node.get_logger().info('KeyboardInterrupt, shutting down.\n')
    node.destroy_node()

    # rclpy.init(args=args)
    # node = SubscriberNode('subscriber_node')
    # rclpy.spin(node)
    # node.destroy_node()
    # rclpy.shutdown()
